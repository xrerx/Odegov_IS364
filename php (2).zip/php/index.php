<?php

function load_products_from_ini($filename) {
    $products = parse_ini_file($filename,true);
    $results = [];

    foreach ($products as $key => $product) {
        $results["$key"]= $product;
    }
    return $results;
    }

    function display_product_cards($product) {
        echo '<div class="product-card">';
        echo '<h2>' . htmlspecialchars($product['name']) . '</h2>';
        echo '<p>ID: ' . htmlspecialchars($product['id']) . '</p>';
        echo '<p>Описание: ' . htmlspecialchars($product['description']) . '</p>';
        echo '<p>Цена: ' . htmlspecialchars($product['price']) . ' рублей</p>';
        echo '<p>Количество на складе: ' . htmlspecialchars($product['stock']) . '</p>';
        echo '</div>';
 }
 function display_products($products){
    foreach ($products as $product){
        display_product_cards($product);
    }
 }

 $filname = 'products.ini';
 $products = load_products_from_ini(filename: $filname);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Карточки товаров</title>
    <style>
        .product-card {
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin: 10px;
            width: 220px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <h1>Товары</h1>
    <?php display_products($products) ?>
</body>
</html>


<!-- Одегов -->